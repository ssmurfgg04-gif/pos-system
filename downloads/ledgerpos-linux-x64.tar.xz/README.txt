LedgerPOS 1.1.1

  tar xf ledgerpos-linux-x64.tar.xz
  ./ledgerpos

The app opens in its own window. First login: admin / admin123.
Data lives in ~/.local/share/LedgerPOS.
