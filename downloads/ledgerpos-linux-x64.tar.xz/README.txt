LedgerPOS 1.0.0

  tar xf ledgerpos-linux-x64.tar.xz
  ./ledgerpos

The app opens in your browser. First login: admin / admin123.
Data lives in ~/.local/share/LedgerPOS.
